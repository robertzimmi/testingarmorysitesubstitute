# app/services/box_service.py
import os
from boxsdk import Client, OAuth2
from flask import flash
from app.tokens_box import load_tokens, save_tokens

def upload_to_box(file_stream, file_name, folder_name):
    try:
        access_token, refresh_token = load_tokens()

        oauth = OAuth2(
            client_id=os.getenv("BOX_CLIENT_ID"),
            client_secret=os.getenv("BOX_CLIENT_SECRET"),
            access_token=access_token,
            refresh_token=refresh_token,
            store_tokens=save_tokens
        )
        client = Client(oauth)

        # Procurar ou criar pasta
        root_folder = client.folder('0')
        folder_id = None
        for item in root_folder.get_items():
            if item.type == 'folder' and item.name == folder_name:
                folder_id = item.id
                break

        if folder_id is None:
            folder_id = root_folder.create_subfolder(folder_name).id

        folder = client.folder(folder_id)

        # Verificar se arquivo já existe
        existing_file = None
        for item in folder.get_items():
            if item.type == 'file' and item.name == file_name:
                existing_file = item
                break

        file_stream.seek(0)

        if existing_file:
            updated_file = existing_file.update_contents(file_stream)
            return f"✅ Arquivo '{updated_file.name}' atualizado com sucesso na pasta '{folder_name}'!"
        else:
            uploaded_file = folder.upload_stream(file_stream, file_name)
            return f"✅ Arquivo '{uploaded_file.name}' enviado para a pasta '{folder_name}' no Box com sucesso!"

    except Exception as e:
        return f"❌ Erro ao enviar arquivo para o Box: {repr(e)}"
