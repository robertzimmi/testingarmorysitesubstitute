import csv
import os
from io import StringIO, BytesIO
import pandas as pd
from flask import flash, redirect, url_for, session
from werkzeug.utils import secure_filename

from app.services.db import connect_db, disconnect_db
from app.services.box_service import upload_to_box

ALLOWED_EXTENSIONS = {'.csv'}

def allowed_file(filename):
    return os.path.splitext(filename)[1].lower() in ALLOWED_EXTENSIONS

def insert_heroes_from_csv(file, data, loja, formato, cur):
    content = file.read()
    lines = content.strip().splitlines()

    corrected_rows = []
    for line in lines[1:]:
        parts = line.split(',', 3)
        if len(parts) == 4:
            player_name, player_id, country, hero = [x.strip().strip('"') for x in parts]
            corrected_rows.append([
                player_name, player_id, country, hero,
                data, loja, formato, session.get("usuario", "desconhecido")
            ])

    if not corrected_rows:
        flash("❗ Nenhuma linha válida encontrada no CSV.", "warning")
        raise ValueError("Nenhuma linha válida encontrada no CSV.")

    buffer = StringIO()
    writer = csv.writer(buffer, delimiter='\t', quoting=csv.QUOTE_NONE, escapechar='\\')
    writer.writerows(corrected_rows)
    buffer.seek(0)

    cur.copy_from(
        buffer,
        'heroes',
        sep='\t',
        columns=('PlayerName', 'PlayerID', 'Country', 'Hero', 'Data', 'Loja', 'Formato', 'usuario')
    )
    return "Dados inseridos com sucesso na tabela heroes!"

def insert_standings_from_csv(file, data, loja, formato, cur):
    df = pd.read_csv(file, encoding='utf-8-sig', dtype=str)
    df['Data'] = data
    df['Loja'] = loja
    df['Formato'] = formato
    df['usuario'] = session.get("usuario", "desconhecido")

    df = df[['Rank', 'Name', 'Player ID', 'Wins', 'Data', 'Loja', 'Formato', 'usuario']]
    df = df.rename(columns={'Player ID': 'PlayerID'})
    df = df.fillna('').astype(str)

    buffer = StringIO()
    df.to_csv(buffer, sep='\t', index=False, header=False, quoting=csv.QUOTE_NONE, escapechar='\\')
    buffer.seek(0)

    cur.copy_from(
        buffer,
        'standings',
        sep='\t',
        columns=('Rank', 'Name', 'PlayerID', 'Wins', 'Data', 'Loja', 'Formato', 'usuario')
    )
    return "Dados inseridos com sucesso na tabela standings!"

def insert_pairings_from_csv(file, data, loja, formato, cur):
    df = pd.read_csv(file, encoding='utf-8-sig', dtype=str)
    df['Data'] = data
    df['Loja'] = loja
    df['Formato'] = formato
    df['usuario'] = session.get("usuario", "desconhecido")

    df = df[['Round', 'Table', 'Player 1 Name', 'Player 1 ID',
             'Player 2 Name', 'Player 2 ID', 'Result',
             'Data', 'Loja', 'Formato', 'usuario']]
    df = df.fillna('').astype(str)

    buffer = StringIO()
    df.to_csv(buffer, sep='\t', index=False, header=False, quoting=csv.QUOTE_NONE, escapechar='\\')
    buffer.seek(0)

    cur.copy_from(
        buffer,
        'pairings',
        sep='\t',
        columns=('Round', 'Table', 'Player1Name', 'Player1ID',
                 'Player2Name', 'Player2ID', 'Result',
                 'Data', 'Loja', 'Formato', 'usuario')
    )
    return "Dados inseridos com sucesso na tabela pairings!"

def insert_calendar_entry(data, loja, cur):
    usuario = session.get("usuario", "desconhecido")
    cur.execute("SELECT 1 FROM calendar WHERE data = %s AND loja = %s", (data, loja))
    exists = cur.fetchone()

    if not exists:
        loja_lower = loja.lower()
        cor = 'blue'
        if "caverna" in loja_lower:
            cor = 'red'
        elif "arena" in loja_lower:
            cor = 'orange'

        cur.execute(
            "INSERT INTO calendar (data, loja, cor, usuario) VALUES (%s, %s, %s, %s)",
            (data, loja, cor, usuario)
        )
        return "Evento adicionado ao calendário com sucesso!"
    else:
        return "Evento já existe no calendário. Nenhuma ação foi tomada."

def process_upload_csv(request):
    conn = None
    try:
        required_fields = ['data', 'loja', 'formato']
        for field in required_fields:
            if not request.form.get(field):
                return f"❌ Campo obrigatório '{field}' não foi fornecido.", 400

        heroes_file = request.files['heroes']
        standings_file = request.files['standings']
        pairings_file = request.files['pairings']

        for f in [heroes_file, standings_file, pairings_file]:
            if not allowed_file(f.filename):
                return f"❌ Arquivo inválido: {f.filename}. Apenas .csv são permitidos.", 400

        heroes_data = heroes_file.read()
        standings_data = standings_file.read()
        pairings_data = pairings_file.read()

        data = request.form['data'].strip()
        loja = request.form['loja'].strip()
        formato = request.form['formato'].strip()
        pasta_box = f"{loja}_{data}_{formato}"

        conn = connect_db()
        cur = conn.cursor()

        result_heroes = insert_heroes_from_csv(StringIO(heroes_data.decode('utf-8-sig')), data, loja, formato, cur)
        result_standings = insert_standings_from_csv(StringIO(standings_data.decode('utf-8-sig')), data, loja, formato, cur)
        result_pairings = insert_pairings_from_csv(StringIO(pairings_data.decode('utf-8-sig')), data, loja, formato, cur)
        calendar_result = insert_calendar_entry(data, loja, cur)

        conn.commit()

        box_heroes = upload_to_box(BytesIO(heroes_data), secure_filename(heroes_file.filename), pasta_box)
        box_standings = upload_to_box(BytesIO(standings_data), secure_filename(standings_file.filename), pasta_box)
        box_pairings = upload_to_box(BytesIO(pairings_data), secure_filename(pairings_file.filename), pasta_box)

        if any(msg.startswith("❌") for msg in [box_heroes, box_standings, box_pairings]):
            flash("❌ Upload para o Box falhou. Os dados foram salvos no banco, mas não no Box.", "error")
            flash(box_heroes, "error")
            flash(box_standings, "error")
            flash(box_pairings, "error")
            return redirect(url_for('upload.uploadcsv'))

        flash(box_heroes, "success")
        flash(box_standings, "success")
        flash(box_pairings, "success")
        flash(result_heroes, "success")
        flash(result_standings, "success")
        flash(result_pairings, "success")
        flash(calendar_result, "info")
        return redirect(url_for('upload.uploadcsv'))

    except Exception as e:
        if conn:
            conn.rollback()
        flash(f"❌ Erro no processamento geral do upload: {repr(e)}", "error")
        return redirect(url_for('upload.uploadcsv'))
    finally:
        disconnect_db(conn)
