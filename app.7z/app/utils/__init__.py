# app/utils/__init__.py

# Importações opcionais de funções comuns
from .helpers import (
    allowed_file,
    login_required,
    str_to_date,
    format_date,
    cor_por_loja
)
