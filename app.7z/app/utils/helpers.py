# app/utils/helpers.py
import os
from datetime import datetime
from flask import session, redirect, url_for
from functools import wraps

ALLOWED_EXTENSIONS = {'.csv'}

def allowed_file(filename):
    """
    Verifica se o arquivo tem uma extensão permitida.
    """
    return os.path.splitext(filename)[1].lower() in ALLOWED_EXTENSIONS

def login_required(f):
    """
    Decorador para proteger rotas que exigem login.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logado'):
            return redirect(url_for('auth.login'))  # ou 'login' direto se não estiver com blueprint
        return f(*args, **kwargs)
    return decorated_function

def str_to_date(date_str, fmt="%Y-%m-%d"):
    """
    Converte string para datetime.date, retorna None se falhar.
    """
    try:
        return datetime.strptime(date_str, fmt).date()
    except ValueError:
        return None

def format_date(date_obj, fmt="%Y-%m-%d"):
    """
    Formata objeto datetime/date para string.
    """
    return date_obj.strftime(fmt)

def cor_por_loja(loja: str) -> str:
    """
    Define cor com base na loja para o calendário.
    """
    loja = loja.lower()
    if "caverna" in loja:
        return 'red'
    elif "arena" in loja:
        return 'orange'
    return 'blue'
