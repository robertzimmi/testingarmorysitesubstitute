# app/routes/upload_routes.py
from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.services.upload_service import process_upload_csv
from app.utils.auth_utils import login_required

upload_bp = Blueprint('upload', __name__)

@upload_bp.route('/uploadcsv')
@login_required
def uploadcsv():
    return render_template('uploadcsv.html')

@upload_bp.route('/upload', methods=['POST'])
@login_required
def upload():
    return process_upload_csv(request)
