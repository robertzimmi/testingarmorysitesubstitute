from flask import Blueprint, render_template
from app.utils.auth_utils import login_required

main_bp = Blueprint('main', __name__)

@main_bp.route('/', endpoint='index')  # ✅ Define endpoint global
def index():
    return render_template('home.html')

@main_bp.route('/base')
@login_required
def base():
    return render_template('base.html')

@main_bp.route('/calendario')
@login_required
def calendario():
    return render_template('calendar.html')

@main_bp.route('/calendar')
def calendar_data():
    # lógica que busca eventos no banco
    pass
